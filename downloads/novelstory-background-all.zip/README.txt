NovelStory 배경 이미지 — 407종

전체 1672×941픽셀 WebP 이미지입니다. 원고 주변을 차분하게 비워 두고 장식은 가장자리에 배치했습니다.
NovelStory Studio의 기존 11개 테마에 어울리는 배경 292종과 별도 색감 5개 묶음 115종을 제공합니다.

사용 방법
1. ZIP을 원하는 폴더에 압축 해제합니다.
2. index.html을 브라우저로 열면 407개 이미지를 폴더·소재·밝기별로 골라 볼 수 있습니다.
3. backgrounds/<테마 ID>/ 폴더에서 원하는 WebP를 선택해 이미지 배경을 지원하는 프로그램에서 사용합니다.
4. 밝은 배경에는 짙은 글씨, 어두운 배경에는 밝은 글씨를 조합하세요.

이 ZIP은 이미지 파일 모음입니다. NovelStory Studio에 테마를 자동 설치하거나 현재 테마를 바꾸지 않습니다.
NovelStory Studio에서는 사용자 테마 팩의 집필 배경 이미지로 사용할 수 있습니다.
미리보기의 예시 문장은 이미지 파일 자체에 들어 있지 않습니다.

폴더 구성
밤 dark 29종 / 먹 ink 27종 / 숲 forest 26종 / 메탈 metal 25종 / 사이버펑크 cyberpunk 27종
낮 light 28종 / 세피아 sepia 29종 / 새벽 dawn 24종 / 화이트 white 26종 / 크리스탈 crystal 25종 / 벚꽃 sakura 26종
따뜻한 다크 warm-dark 26종 / 그린 라이트 green-light 23종 / 파스텔 라이트 pastel-light 23종 / 청록 다크 teal-dark 22종 / 자주 다크 plum-dark 21종

생성 경위와 규격은 SOURCES.md, 이미지별 목록은 catalog.json, 파일 무결성 확인값은 SHA256SUMS.txt에 있습니다.
저장소: https://github.com/HoneyOfOneDayButterfly/novelstory-background
테마별 ZIP: https://github.com/HoneyOfOneDayButterfly/novelstory-background/tree/main/downloads
