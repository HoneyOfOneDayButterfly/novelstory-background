사이버펑크 테마 배경 이미지
포함 이미지: 27개
이미지 규격: 1672×941 WebP
밝은 배경에는 짙은 글씨를, 어두운 배경에는 밝은 글씨를 조합하세요.
이미지 파일 모음이며 자동 설치 팩이 아닙니다.
압축을 푼 뒤 backgrounds/cyberpunk/ 안의 이미지를 사용하세요.
공식 저장소: https://github.com/HoneyOfOneDayButterfly/novelstory-background
